#include "WriteXML.h"

using namespace std;

WriteXML::WriteXML(const string &_filename)
{
	filename = _filename;
}

WriteXML::~WriteXML()
{

}

void WriteXML::WriteXMLConnection(Connection &net_connection)
{
	connection = new TiXmlElement("Connection");
	neuron->LinkEndChild(connection);
	connection->SetDoubleAttribute("weight", net_connection.weight);
	connection->SetDoubleAttribute("deltaWeight", net_connection.deltaWeight);
}

void WriteXML::WriteXMLNeuron(Neuron *net_neuron)
{
	neuron = new TiXmlElement("Neuron");
	layer->LinkEndChild(neuron);
	neuron->SetAttribute("func", net_neuron->getTransferFunction());

	for(int i = 0; i < net_neuron->getOutputWeights().size(); i++)
	{
		WriteXMLConnection(net_neuron->getOutputWeights()[i]);
	}
}

void WriteXML::WriteXMLLayer(Layer &net_layer)
{
	layer = new TiXmlElement("Layer");  
	root->LinkEndChild(layer);
	Neuron *net_neuron;

	for(int i = 0; i<net_layer.size(); i++)
	{
		net_neuron = &(net_layer[i]);
		WriteXMLNeuron(net_neuron);
	}
}

void WriteXML::WriteXMLNetwork(NN &net)
{
	root = new TiXmlElement("Network");  
	doc.LinkEndChild(root);
	Layer net_layer;
	root->SetDoubleAttribute("m_recentAverageError", net.getRecentAverageError());

	for(int i = 0; i < net.getNumLayers(); i++)
	{
		net_layer = net.getLayer(i);
		WriteXMLLayer(net_layer);
	}

	doc.SaveFile(filename.c_str()); 
}