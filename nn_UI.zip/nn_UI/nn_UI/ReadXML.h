#pragma once
#include "tinyxml.h"
#include <iostream>
#include <string>
#include "NN.h"
#include <vector>

using namespace std;

class ReadXML
{
	TiXmlDocument doc;
	string filename;
	TiXmlElement *root;
	TiXmlElement *layer;
	TiXmlElement *neuron;
	TiXmlElement *connection;
	bool loadOkay;
	vector<unsigned> topology;

public:
	ReadXML(const string &);
	~ReadXML();
	void ReadXMLNetwork(NN &net);
	void ReadXMLLayer(NN &net);
	void ReadXMLNeuron(unsigned layer_num, NN &net);
	void ReadXMLConnection(unsigned layer_num, unsigned neuron_num, NN &net);
	vector<unsigned> & ReadTopology();
};