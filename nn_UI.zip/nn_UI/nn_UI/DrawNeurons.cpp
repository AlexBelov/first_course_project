#pragma once
#include "stdafx.h"
#include "DrawNeurons.h"

DrawNeurons::DrawNeurons(vector<unsigned> &_topology, double _panelWidth, double _panelHeight)
{
	topology = _topology;
	panelWidth = _panelWidth;
	panelHeight = _panelHeight;
}

DrawNeurons::~DrawNeurons()
{

}

void DrawNeurons::CalculateAllCoordinates()
{
	double x_layer = (panelWidth)/(topology.size() + 1);
	double y_layer;
	NeuroCoordinates temp;
	NeuroLayer temp_layer;

	for(int i = 0; i < topology.size(); i++)
	{
		layers.push_back(temp_layer);
		y_layer = (panelHeight)/(topology[i] + 1); // +2 to display bias

		for (int j = 0; j < topology[i]; j++) // <= to display bias
		{
			temp.x = x_layer * (i + 1);
			temp.y = y_layer * (j + 1);

			if (0.5 * x_layer < 0.5 * y_layer)
				temp.neuronRadius = 0.3 * x_layer;
			else
				temp.neuronRadius = 0.3 * y_layer;
			if (temp.neuronRadius < 3) temp.neuronRadius = 3;

			temp.leftCorner.x = temp.x - temp.neuronRadius;
			temp.leftCorner.y = temp.y - temp.neuronRadius;

			temp.dimensions.width = 2 * temp.neuronRadius;
			temp.dimensions.height = 2 * temp.neuronRadius;

			layers.back().push_back(temp);
		}
	
	}
}

NeuroLayer & DrawNeurons::getLayer(unsigned i)
{
	return layers[i];
}

void DrawNeurons::CalculateAllConnections()
{
	NeuroConnection temp;

	for (unsigned layer = 0; layer < (topology.size() - 1); layer++)
	{
		NeuroLayer current = layers[layer];
		NeuroLayer next = layers[layer + 1];

		for (unsigned i = 0; i < current.size(); i++)
		{
			for (unsigned j = 0; j < next.size(); j++) // j < (next.size() - 1) to displaye bias
			{
				temp.x1 = current[i].x;
				temp.y1 = current[i].y;
				temp.x2 = next[j].x;
				temp.y2 = next[j].y;

				connections.push_back(temp);
			}
		}
	}
}

vector<NeuroConnection> & DrawNeurons::getConnections()
{
	return connections;
}

void DrawNeurons::Draw(System::Windows::Forms::PaintEventArgs^  e, Panel^  panel, vector<unsigned> &_topology)
{
	Graphics^ g = e->Graphics;

	double width = double(panel->Size.Width);
	double height = double(panel->Size.Height);

	DrawNeurons draw(_topology, width, height);
	draw.CalculateAllCoordinates();
	draw.CalculateAllConnections();

	//********** Lines **************
	for (unsigned i = 0; i < draw.getConnections().size(); i++)
	{
		int x1 = int(draw.getConnections()[i].x1);
		int y1 = int(draw.getConnections()[i].y1);
		int x2 = int(draw.getConnections()[i].x2);
		int y2 = int(draw.getConnections()[i].y2);
		g->DrawLine(Pens::Black, x1, y1, x2, y2);
	}

	//********** Neurons **************
	for(int i = 0; i < _topology.size(); i++)
	{
		for(int j = 0; j < _topology[i]; j++)
		{
			int x = int(draw.getLayer(i)[j].leftCorner.x);
			int y = int(draw.getLayer(i)[j].leftCorner.y);
			int dim = int(draw.getLayer(i)[j].dimensions.height);
			g->FillEllipse(Brushes::Black, x-2,y-2,dim+4,dim+4);
			g->FillEllipse(Brushes::Red, x,y,dim,dim);
		}
	}
}