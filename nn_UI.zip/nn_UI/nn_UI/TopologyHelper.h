#pragma once
#include <vector>

using namespace std;

class TopologyHelper
{
public:
	static TopologyHelper & getInstance()
	{
		static TopologyHelper instance;
		return instance;
	}

	vector<unsigned> topology;

private:
	TopologyHelper(){}
};