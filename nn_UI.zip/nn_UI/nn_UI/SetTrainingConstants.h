#pragma once

#include "VectorAndString.h"
#include <vector>
#include "EtaAlphaHelper.h"

using namespace std;

namespace nn_UI {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for SetTrainingConstants
	/// </summary>
	public ref class SetTrainingConstants : public System::Windows::Forms::Form
	{
	public:
		SetTrainingConstants(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~SetTrainingConstants()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^  label1;
	protected: 
	private: System::Windows::Forms::Label^  label2;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::Label^  label3;
	private: System::Windows::Forms::Label^  label4;
	private: System::Windows::Forms::TextBox^  textBox1;
	private: System::Windows::Forms::TextBox^  textBox2;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	private: System::Windows::Forms::Label^  label6;
	private: System::Windows::Forms::Label^  label5;


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->label4 = (gcnew System::Windows::Forms::Label());
			this->textBox1 = (gcnew System::Windows::Forms::TextBox());
			this->textBox2 = (gcnew System::Windows::Forms::TextBox());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			this->label5 = (gcnew System::Windows::Forms::Label());
			this->label6 = (gcnew System::Windows::Forms::Label());
			this->groupBox1->SuspendLayout();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(8, 16);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(128, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"�������� �������� (eta)";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(8, 106);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(221, 13);
			this->label2->TabIndex = 1;
			this->label2->Text = L"��������� ����������� �������� (alpha)";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(11, 191);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(218, 40);
			this->button1->TabIndex = 2;
			this->button1->Text = L"���������� ���������";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &SetTrainingConstants::button1_Click);
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(8, 56);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(53, 13);
			this->label3->TabIndex = 4;
			this->label3->Text = L"�� 0 �� 1";
			// 
			// label4
			// 
			this->label4->AutoSize = true;
			this->label4->Location = System::Drawing::Point(8, 142);
			this->label4->Name = L"label4";
			this->label4->Size = System::Drawing::Size(29, 13);
			this->label4->TabIndex = 5;
			this->label4->Text = L"�� 0";
			// 
			// textBox1
			// 
			this->textBox1->Location = System::Drawing::Point(11, 72);
			this->textBox1->Name = L"textBox1";
			this->textBox1->Size = System::Drawing::Size(100, 20);
			this->textBox1->TabIndex = 6;
			// 
			// textBox2
			// 
			this->textBox2->Location = System::Drawing::Point(11, 158);
			this->textBox2->Name = L"textBox2";
			this->textBox2->Size = System::Drawing::Size(100, 20);
			this->textBox2->TabIndex = 7;
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->label6);
			this->groupBox1->Controls->Add(this->label5);
			this->groupBox1->Controls->Add(this->textBox2);
			this->groupBox1->Controls->Add(this->textBox1);
			this->groupBox1->Controls->Add(this->label4);
			this->groupBox1->Controls->Add(this->label3);
			this->groupBox1->Controls->Add(this->button1);
			this->groupBox1->Controls->Add(this->label2);
			this->groupBox1->Controls->Add(this->label1);
			this->groupBox1->Location = System::Drawing::Point(5, -1);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(238, 238);
			this->groupBox1->TabIndex = 8;
			this->groupBox1->TabStop = false;
			// 
			// label5
			// 
			this->label5->AutoSize = true;
			this->label5->Location = System::Drawing::Point(7, 33);
			this->label5->Name = L"label5";
			this->label5->Size = System::Drawing::Size(104, 13);
			this->label5->TabIndex = 8;
			this->label5->Text = L"�� ��������� 0.15";
			// 
			// label6
			// 
			this->label6->AutoSize = true;
			this->label6->Location = System::Drawing::Point(10, 123);
			this->label6->Name = L"label6";
			this->label6->Size = System::Drawing::Size(98, 13);
			this->label6->TabIndex = 9;
			this->label6->Text = L"�� ��������� 0.3";
			// 
			// SetTrainingConstants
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(248, 242);
			this->Controls->Add(this->groupBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->Name = L"SetTrainingConstants";
			this->Text = L"��������� ��������";
			this->groupBox1->ResumeLayout(false);
			this->groupBox1->PerformLayout();
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				 vector<double> eta;
				 vector<double> alpha;
				 String ^etaval;
				 String ^alphaval;

				 EtaAlphaHelper helper = EtaAlphaHelper::getInstance();
				 
				 if (!String::IsNullOrEmpty(textBox1->Text))
				 {
					 etaval = textBox1->Text;
					 eta = VectorAndString::StringToVector(etaval);
					 if (eta.size() != 1)
					 {
						 MessageBox::Show("�������� �������� ����!");
						 return;
					 }
					 if (eta[0] > 1 || eta[0] < 0)
					 {
						 MessageBox::Show("�������� �������� ����!");
						 return;
					 }
					 //MessageBox::Show(Convert::ToString(eta[0]));
					 helper.eta = eta[0];
				 }

				 if (!String::IsNullOrEmpty(textBox2->Text))
				 {
					 alphaval = textBox2->Text;
					 alpha = VectorAndString::StringToVector(alphaval);
					 if (alpha.size() != 1)
					 {
						 MessageBox::Show("�������� �������� ����!");
						 return;
					 }
					 //MessageBox::Show(Convert::ToString(alpha[0]));
					 helper.alpha = alpha[0];
				 }

				 textBox1->Text = "";
				 textBox2->Text = "";

				 if (alpha.size() || eta.size()) this->Close();
			 }
};
}
