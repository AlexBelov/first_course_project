#pragma once
#include <vector>

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace std;

struct NeuroCoordinates
{
	double x;
	double y;
	double neuronRadius;

	struct LeftCorner
	{
		double x;
		double y;
	}leftCorner;

	struct Dimensions
	{
		double width;
		double height;
	}dimensions;
};

struct NeuroConnection
{
	double x1;
	double y1;
	double x2;
	double y2;
};

typedef vector<NeuroCoordinates> NeuroLayer;

class DrawNeurons
{
	vector<NeuroLayer> layers;
	vector<NeuroConnection> connections;
	vector<unsigned> topology;
	double panelWidth;
	double panelHeight;

public:
	DrawNeurons(vector<unsigned> &_topology, double _panelWidth, double _panelHeight);
	~DrawNeurons();
	void CalculateAllCoordinates();
	void CalculateAllConnections();
	NeuroLayer & getLayer(unsigned i);
	vector<NeuroConnection> & getConnections();
	static void Draw(System::Windows::Forms::PaintEventArgs^  e, Panel^  panel, vector<unsigned> &_topology);
};