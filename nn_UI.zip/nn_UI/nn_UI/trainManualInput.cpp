#include "StdAfx.h"
#include "trainManualInput.h"

