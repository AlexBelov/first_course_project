#pragma once
#include "addLayer.h"
#include "TopologyHelper.h"

using namespace std;

namespace nn_UI {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Summary for nnMaster
	/// </summary>
	public ref class nnMaster : public System::Windows::Forms::Form
	{
	public:
		nnMaster()
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
			count = 1;
		}
	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~nnMaster()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::DataGridView^  dataGridView1;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  Layer;
	private: System::Windows::Forms::DataGridViewTextBoxColumn^  numNeurons;
	private: System::Windows::Forms::Button^  button1;
	private: System::Windows::Forms::GroupBox^  groupBox1;
	protected: 



	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		int count;
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->Layer = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->numNeurons = (gcnew System::Windows::Forms::DataGridViewTextBoxColumn());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->groupBox1 = (gcnew System::Windows::Forms::GroupBox());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->BeginInit();
			this->groupBox1->SuspendLayout();
			this->SuspendLayout();
			// 
			// dataGridView1
			// 
			this->dataGridView1->AccessibleRole = System::Windows::Forms::AccessibleRole::None;
			this->dataGridView1->AllowUserToDeleteRows = false;
			this->dataGridView1->BackgroundColor = System::Drawing::SystemColors::ControlLightLight;
			this->dataGridView1->BorderStyle = System::Windows::Forms::BorderStyle::None;
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Columns->AddRange(gcnew cli::array< System::Windows::Forms::DataGridViewColumn^  >(2) {this->Layer, 
				this->numNeurons});
			this->dataGridView1->GridColor = System::Drawing::SystemColors::ControlLight;
			this->dataGridView1->Location = System::Drawing::Point(6, 12);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->ReadOnly = true;
			this->dataGridView1->RowHeadersVisible = false;
			this->dataGridView1->ShowCellErrors = false;
			this->dataGridView1->ShowCellToolTips = false;
			this->dataGridView1->ShowEditingIcon = false;
			this->dataGridView1->ShowRowErrors = false;
			this->dataGridView1->Size = System::Drawing::Size(231, 239);
			this->dataGridView1->TabIndex = 0;
			this->dataGridView1->CellContentClick += gcnew System::Windows::Forms::DataGridViewCellEventHandler(this, &nnMaster::dataGridView1_CellContentClick);
			this->dataGridView1->KeyDown += gcnew System::Windows::Forms::KeyEventHandler(this, &nnMaster::dataGridView1_KeyDown);
			// 
			// Layer
			// 
			this->Layer->HeaderText = L"����";
			this->Layer->Name = L"Layer";
			this->Layer->ReadOnly = true;
			// 
			// numNeurons
			// 
			this->numNeurons->HeaderText = L"����� ��������";
			this->numNeurons->Name = L"numNeurons";
			this->numNeurons->ReadOnly = true;
			this->numNeurons->Width = 130;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(6, 263);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(231, 23);
			this->button1->TabIndex = 1;
			this->button1->Text = L"�������� ����";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &nnMaster::button1_Click);
			// 
			// groupBox1
			// 
			this->groupBox1->Controls->Add(this->button1);
			this->groupBox1->Controls->Add(this->dataGridView1);
			this->groupBox1->Location = System::Drawing::Point(6, 0);
			this->groupBox1->Name = L"groupBox1";
			this->groupBox1->Size = System::Drawing::Size(243, 292);
			this->groupBox1->TabIndex = 2;
			this->groupBox1->TabStop = false;
			// 
			// nnMaster
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(254, 296);
			this->Controls->Add(this->groupBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->Name = L"nnMaster";
			this->Text = L"������ �������� ����";
			this->Load += gcnew System::EventHandler(this, &nnMaster::nnMaster_Load);
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^  >(this->dataGridView1))->EndInit();
			this->groupBox1->ResumeLayout(false);
			this->ResumeLayout(false);

		}
#pragma endregion
	private: System::Void dataGridView1_CellContentClick(System::Object^  sender, System::Windows::Forms::DataGridViewCellEventArgs^  e) {
			 }
	private: System::Void button1_Click(System::Object^  sender, System::EventArgs^  e) {
				 addLayer ^add = gcnew addLayer();
				 add->ShowDialog();
				 unsigned num = add->num;;
				 if (num)
				 {
					TopologyHelper &top = TopologyHelper::getInstance();
					top.topology.push_back(num);

					/*DataGridViewRow ^row = gcnew DataGridViewRow();
					row->Cells. = "10";*/
					this->dataGridView1->Rows->Add(Convert::ToString(count), Convert::ToString(num));
					count++;
				 }
			 }
private: System::Void dataGridView1_KeyDown(System::Object^  sender, System::Windows::Forms::KeyEventArgs^  e) {
			 if (e->KeyCode == Keys::Enter)
			 {
				 addLayer ^add = gcnew addLayer();
				 add->ShowDialog();
				 unsigned num = add->num;
				 if (num)
				 {
					TopologyHelper &top = TopologyHelper::getInstance();
					top.topology.push_back(num);

					/*DataGridViewRow ^row = gcnew DataGridViewRow();
					row->Cells. = "10";*/
					this->dataGridView1->Rows->Add(Convert::ToString(count), Convert::ToString(num));
					count++;
				 }
			 }
			 if (e->KeyCode == Keys::Escape)
			 {
				 this->Close();
			 }
		 }
private: System::Void nnMaster_Load(System::Object^  sender, System::EventArgs^  e) {
			 TopologyHelper &top = TopologyHelper::getInstance();
			 for (int i = 0; i < top.topology.size(); i++)
			 {
				 this->dataGridView1->Rows->Add(Convert::ToString(count), Convert::ToString(top.topology[count - 1]));
				 count++;
			 }
		 }
};
}
