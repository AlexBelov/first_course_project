#pragma once
#include "TrainingData.h"

TrainingData::TrainingData(const string &_filename)
{
	filename = _filename;
	TiXmlDocument newdoc(filename.c_str());
	doc = newdoc;
	loadOkay = doc.LoadFile();
	isDone = false;

	if(loadOkay)
	{
		training = doc.FirstChildElement("Training");
		dataset = training->FirstChildElement("Dataset");
	}
}

TrainingData::~TrainingData()
{

}

unsigned TrainingData::getNextInputs(vector<double> &inputVals)
{
	TiXmlElement *input;
	TiXmlElement *val;

	if (dataset)
	{
		inputVals.clear();
		input = dataset->FirstChildElement("Input");
		val = input->FirstChildElement("Value");
		do 
		{
			inputVals.push_back(atof(val->Attribute("val")));
			val = val->NextSiblingElement("Value");
		} while (val);
	}

	return inputVals.size();
}

unsigned TrainingData::getTargetOutputs(vector<double> &targetOutputVals)
{
	TiXmlElement *output;
	TiXmlElement *val;

	if (dataset)
	{
		targetOutputVals.clear();
		output = dataset->FirstChildElement("Output");
		val = output->FirstChildElement("Value");
		do 
		{
			targetOutputVals.push_back(atof(val->Attribute("val")));
			val = val->NextSiblingElement("Value");
		} while (val);

		dataset = dataset->NextSiblingElement("Dataset");
	}
	if(!dataset)
	{
		isDone = true;
	}

	return targetOutputVals.size();
}

bool TrainingData::Train(NN &net, const string &filename)
{
	TrainingData trainData(filename.c_str());

	vector<double> inputVals, targetVals, resultVals;
	int trainingPass = 0;

	while(!trainData.isEnd())
	{
		++trainingPass;
		if (trainData.getNextInputs(inputVals) != net.topology[0]) 
		{
			break;
		}

		net.feedForward(inputVals);
		// Collect the net's actual output results:
		net.getResults(resultVals);
		trainData.getTargetOutputs(targetVals);

		assert(targetVals.size() == net.topology.back());

		net.backProp(targetVals);

		/*cout << resultVals[0];
		cout << "NN recent average error: "
		<< net.getRecentAverageError() << endl;*/
	}

	return true;
}