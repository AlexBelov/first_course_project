#pragma once
#include "VectorAndString.h"
#include <sstream>
#include <msclr/marshal_cppstd.h>

using namespace msclr::interop;

std::vector<double> VectorAndString::StringToVector(System::String ^str)
{
	std::string s;

	s = marshal_as<std::string>(str);
	std::vector<double> input;
	std::size_t pos = 0;
	double d = 0.0;
	while (pos < s.size ())
		if ((pos = s.find_first_of (';',pos)) != std::string::npos)
			s[pos] = ' ';
	std::stringstream ss(s);
	while (ss >> d)
		input.push_back (d);

	return input;
}

System::String ^ VectorAndString::VectorToString(std::vector<double> &vector)
{
	std::string s;
	System::String ^temp;

	std::stringstream ss;
	for (int i = 0; i < vector.size(); i++)
	{
		ss << vector[i];
		s = ss.str();
		if (i != vector.size() - 1) ss << ";";
	}

	temp = marshal_as<System::String ^>(s);
	return temp;
}

std::string VectorAndString::SystemStringToStdString(System::String ^str)
{
	std::string s;
	s = marshal_as<std::string>(str);
	return s;
}