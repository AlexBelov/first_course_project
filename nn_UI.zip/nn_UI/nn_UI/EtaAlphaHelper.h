#pragma once

class EtaAlphaHelper
{
public:
	static EtaAlphaHelper & getInstance()
	{
		static EtaAlphaHelper instance;
		return instance;
	}

	double eta; // [0.0..1.0] overall net training rate
	double alpha; // [0.0..n] multiplier of last weight change

private:
	EtaAlphaHelper()
	{
		eta = 0.15;
		alpha = 0.3;
	}
};