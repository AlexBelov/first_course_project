#pragma once
#include <vector>
#include <string>
#include "tinyxml.h"
#include <vector>
#include <string>
#include "NN.h"

using namespace std;

class TrainingData
{
	string filename;
	bool isDone;
	bool loadOkay;
	TiXmlDocument doc;
	TiXmlElement *root;
	TiXmlElement *layer;
	TiXmlElement *training;
	TiXmlElement *dataset;

public:
	TrainingData(const string &_filename);
	~TrainingData();
	bool isEnd(void) { return isDone; };

	unsigned getNextInputs(vector<double> &inputVals);
	unsigned getTargetOutputs(vector<double> &targetOutputVals);

	static bool Train(NN &net, const string &filename);
};