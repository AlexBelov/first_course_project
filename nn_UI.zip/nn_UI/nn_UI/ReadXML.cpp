#pragma once

#include "ReadXML.h"

using namespace std;

ReadXML::ReadXML(const string &_filename)
{
	filename = _filename;
	TiXmlDocument _doc(filename.c_str());
	doc = _doc;
	loadOkay = doc.LoadFile();
}

ReadXML::~ReadXML()
{

}

void ReadXML::ReadXMLConnection(unsigned layer_num, unsigned neuron_num, NN &net)
{
	vector<Connection> outputWeights;
	Connection temp_connection;
	
	if(connection)
	{
		do 
		{
			temp_connection.weight = atof(connection->Attribute("weight"));
			temp_connection.deltaWeight = atof(connection->Attribute("deltaWeight"));
			outputWeights.push_back(temp_connection);
			connection = connection->NextSiblingElement("Connection");
		} while (connection);
	}
	
	net.getLayer(layer_num)[neuron_num].setOutputWeights(outputWeights);
}

void ReadXML::ReadXMLNeuron(unsigned layer_num, NN &net)
{
	unsigned neuron_num = 0;

	if(neuron)
	{
		do 
		{
			net.getLayer(layer_num)[neuron_num].setTransferFunction(atoi(neuron->Attribute("func")));
			connection = neuron->FirstChildElement("Connection");
			ReadXMLConnection(layer_num, neuron_num, net);
			neuron = neuron->NextSiblingElement("Neuron");
			neuron_num++;
		} while (neuron);
	}
}

void ReadXML::ReadXMLLayer(NN &net)
{
	unsigned layer_num = 0;

	if(layer)
	{
		do 
		{
			neuron = layer->FirstChildElement("Neuron");
			ReadXMLNeuron(layer_num, net);
			layer = layer->NextSiblingElement("Layer");
			layer_num++;
		} while (layer);
	}
}

void ReadXML::ReadXMLNetwork(NN &net)
{
	if (loadOkay)
	{
		//ReadXML::ReadTopology(topology);
		//NN net_internal(topology);
		root = doc.FirstChildElement("Network");

		if (root)
		{
			net.setRecentAverageError(atof(root->Attribute("m_recentAverageError")));

			layer = root->FirstChildElement("Layer");
			ReadXMLLayer(net);
		}
	}
	return;
}

vector<unsigned> & ReadXML::ReadTopology()
{
	if (loadOkay)
	{
	TiXmlElement *troot;
	TiXmlElement *tlayer;
	TiXmlElement *tneuron;
	unsigned num_tneuron = 0;

	troot = doc.FirstChildElement("Network");
	tlayer = troot->FirstChildElement("Layer");
	do 
	{
		num_tneuron = 0;
		tneuron = tlayer->FirstChildElement("Neuron");
		do 
		{
			tneuron = tneuron->NextSiblingElement("Neuron");
			num_tneuron++;
		} while (tneuron);
		topology.push_back(num_tneuron - 1);
		tlayer = tlayer->NextSiblingElement("Layer");
	} while (tlayer);

	}
	return topology;
}