#pragma once;
#include <vector>

class VectorAndString
{
public:
	static std::vector<double> StringToVector(System::String ^str);
	static System::String ^ VectorToString(std::vector<double> &vector);
	static std::string SystemStringToStdString(System::String ^str);
};

