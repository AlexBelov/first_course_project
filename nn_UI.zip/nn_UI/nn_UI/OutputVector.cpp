#pragma once;
#include "OutputVector.h"

OutputVector::OutputVector(const string &_filename)
{
	filename = _filename;
}

OutputVector::~OutputVector()
{

}

void OutputVector::writeOutputVector(vector<double> &resultVals)
{
	TiXmlElement *root;
	TiXmlElement *output;

	root = new TiXmlElement("Output");
	doc.LinkEndChild(root);

	for (int i = 0; i < resultVals.size(); i++)
	{
		output = new TiXmlElement("Value");
		root->LinkEndChild(output);
		output->SetDoubleAttribute("val", resultVals[i]);
	}

	doc.SaveFile(filename.c_str());
}