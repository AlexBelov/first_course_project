#pragma once

struct Connection
{
	double weight;
	double deltaWeight;
};