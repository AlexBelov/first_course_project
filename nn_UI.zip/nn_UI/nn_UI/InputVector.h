#pragma once
#include "tinyxml.h"
#include <string>
#include <vector>

using namespace std;

class InputVector
{
	TiXmlDocument doc;
	string filename;
	bool loadOkay;

public:
	InputVector(const string &_filename);
	~InputVector();
	void getInputVector(vector<double> &inputVals);
};