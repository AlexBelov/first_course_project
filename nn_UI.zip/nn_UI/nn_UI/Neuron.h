#pragma once
#include <vector>
#include <cstdlib>
#include "Connection.h"
#include <cmath>
#include <time.h>
#include "EtaAlphaHelper.h"

using namespace std;

class Neuron;

typedef vector<Neuron> Layer;

class Neuron
{
public:
	enum ActivationFunction{Exponential, Logistic, HyperbolicTangent}; // Activation or Transfer function

private:
	double m_outputVal;
	unsigned m_myIndex;
	double m_gradient;
	vector<Connection> m_outputWeights;
	ActivationFunction activation_function;

	double sumDOW(const Layer &nextLayer) const;
	static double randomWeight(void) { return rand() / double(RAND_MAX); }
	double transferFunction(double x);
	double transferFunctionDerivative(double x);

public:
	Neuron(unsigned numOutputs, unsigned myIndex);
	~Neuron();
	void setOutputVal(double val) { m_outputVal = val; }
	double getOutputVal(void) const { return m_outputVal; }
	void feedForward(const Layer &prevLayer);
	void calcOutputGradients(double targetVal);
	void calcHiddenGradients(const Layer &nextLayer);
	void updateInputWeights(Layer &prevLayer);
	void setTransferFunction(ActivationFunction func);
	void setTransferFunction(int func);
	int getTransferFunction(void);
	vector<Connection> & getOutputWeights(void);
	void setOutputWeights(vector<Connection> &outputWeights);
};