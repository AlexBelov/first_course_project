#pragma once
#include "tinyxml.h"
#include <string>
#include <vector>

using namespace std;

class OutputVector
{
	TiXmlDocument doc;
	string filename;
	
public:
	OutputVector(const string &_filename);
	~OutputVector();
	void writeOutputVector(vector<double> &resultVals);
};