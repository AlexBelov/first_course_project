#pragma once
#include <vector>
#include "Neuron.h"
#include <cassert>
#include <cmath>
#include "EtaAlphaHelper.h"

using namespace std;

typedef vector<Neuron> Layer;

class NN
{
	vector<Layer> m_layers;
	double m_error;
	double m_recentAverageError;
	static double m_recentAverageSmoothingFactor;

public:
	vector<unsigned> topology;

	NN();
	NN(const vector<unsigned> &topology);
	~NN();
	void feedForward(const vector<double> &inputVals);
	void backProp(const vector<double> &targetVals);
	void getResults(vector<double> &resultVals) const;
	double getRecentAverageError(void) const { return m_recentAverageError; }
	void setRecentAverageError(double recentAverageError);
	unsigned getNumLayers(void) const { return m_layers.size(); }
	Layer & getLayer(int num);
	vector<unsigned> & getTopology() { return topology; }
	void setLayerTransferFunction(unsigned layer, int func);
	int getLayerTransferFunction(unsigned layer);

	static NN & getInstance(const vector<unsigned> &topology)
	{
	static NN instance(topology);
	return instance;
	}
};