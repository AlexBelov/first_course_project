#pragma once
#include "tinyxml.h"
#include <string>
#include "NN.h"

using namespace std;

class WriteXML
{
	TiXmlElement *root;
	TiXmlElement *layer;
	TiXmlElement *neuron;
	TiXmlElement *connection;
	TiXmlDocument doc;
	string filename;
public:
	WriteXML(const string &);
	~WriteXML();
	void WriteXMLNetwork(NN &net);
	void WriteXMLLayer(Layer &net_layer);
	void WriteXMLNeuron(Neuron *net_neuron);
	void WriteXMLConnection(Connection &net_connection);
};