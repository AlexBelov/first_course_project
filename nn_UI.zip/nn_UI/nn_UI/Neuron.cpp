#pragma once
#include "Neuron.h"

Neuron::Neuron(unsigned numOutputs, unsigned myIndex)
{
	// Initialise random
	int stime; 
	long ltime;
	ltime=time(NULL);             
	stime=(unsigned) ltime/2;    
	srand(stime);

	for (unsigned c = 0; c < numOutputs; c++)
	{
		m_outputWeights.push_back(Connection());
		m_outputWeights.back().weight = randomWeight();
	}

	activation_function = Neuron::HyperbolicTangent;

	m_myIndex = myIndex;
}

Neuron::~Neuron()
{

}

void Neuron::feedForward(const Layer &prevLayer)
{
	double sum = 0.0;

	for (unsigned n = 0; n < prevLayer.size(); n++)
	{
		sum += prevLayer[n].getOutputVal() *
			prevLayer[n].m_outputWeights[m_myIndex].weight;
	}

	m_outputVal = Neuron::transferFunction(sum);
}

double Neuron::transferFunction(double x)
{
	switch (activation_function)
	{
		case 0:
			{
				return exp(x);
			}
		case 1:
			{
				return 1 / (1 + exp((double) -x));
			}
		case 2:
			{
				return tanh(x);
			}
	}
}

double Neuron::transferFunctionDerivative(double x)
{
	switch (activation_function)
	{
	case 0:
		{
			return exp(x);
		}
	case 1:
		{
			return (1 / (1 + exp((double) -x)))*(1 - (1 / (1 + exp((double) -x))));
		}
	case 2:
		{
			return 1.0 - x*x;
		}
	}
}

void Neuron::calcOutputGradients(double targetVal)
{
	double delta = targetVal - m_outputVal;
	m_gradient = delta * Neuron::transferFunctionDerivative(m_outputVal);
}

void Neuron::calcHiddenGradients(const Layer &nextLayer)
{
	double dow = sumDOW(nextLayer);
	m_gradient = dow * Neuron::transferFunctionDerivative(m_outputVal);
}

double Neuron::sumDOW(const Layer &nextLayer) const
{
	double sum = 0.0;

	for (unsigned n = 0; n < nextLayer.size() - 1; n++)
	{
		sum += m_outputWeights[n].weight * nextLayer[n].m_gradient;
	}

	return sum;
}

void Neuron::updateInputWeights(Layer &prevLayer)
{
	//The weights will be updated

	EtaAlphaHelper e = EtaAlphaHelper::getInstance();

	for (unsigned n = 0; n < prevLayer.size(); n++)
	{
		Neuron &neuron = prevLayer[n];
		double oldDetlaWeight = neuron.m_outputWeights[m_myIndex].deltaWeight;

		double newDeltaWeight =
			//Individual input, magnified by the gradient and train rate
			e.eta
			* neuron.getOutputVal()
			* m_gradient
			//Also add momentum = a fraction of the previous delta weight
			+ e.alpha
			* oldDetlaWeight;

		neuron.m_outputWeights[m_myIndex].deltaWeight = newDeltaWeight;
		neuron.m_outputWeights[m_myIndex].weight += newDeltaWeight; 
	}
}

void Neuron::setTransferFunction(ActivationFunction func)
{
	activation_function = func;
}

void Neuron::setTransferFunction(int func)
{
	switch(func)
	{
	case 0:
		{
			activation_function = Neuron::Exponential;
			break;
		}
	case 1:
		{
			activation_function = Neuron::Logistic;
			break;
		}
	case 2:
		{
			activation_function = Neuron::HyperbolicTangent;
			break;
		}
	default:
		{
			activation_function = Neuron::HyperbolicTangent;
		}
	}
}

int Neuron::getTransferFunction(void)
{
	return activation_function;
}

vector<Connection> & Neuron::getOutputWeights(void)
{
	return m_outputWeights;
}

void Neuron::setOutputWeights(vector<Connection> &outputWeights)
{
	m_outputWeights = outputWeights;
}