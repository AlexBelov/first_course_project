#pragma once
#include "InputVector.h"

InputVector::InputVector(const string &_filename)
{
	filename = _filename;
	TiXmlDocument _doc(filename.c_str());
	doc = _doc;
	loadOkay = doc.LoadFile();
}

InputVector::~InputVector()
{

}

void InputVector::getInputVector(vector<double> &inputVals)
{
	TiXmlElement *root;
	TiXmlElement *value;

	inputVals.clear();

	root = doc.FirstChildElement("Input");
	value = root->FirstChildElement("Value");

	do
	{
		inputVals.push_back(atof(value->Attribute("val")));
		value = value->NextSiblingElement("Value");
	}while(value);
}