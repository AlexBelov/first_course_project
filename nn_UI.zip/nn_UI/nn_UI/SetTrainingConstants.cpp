#include "StdAfx.h"
#include "SetTrainingConstants.h"

